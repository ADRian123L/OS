#include "execute.h"
#include "read_line.h"
#include "vector.h"

char  *error_message = "An error has occurred\n";
char **PATH;
;

int main(int argc, char *argv[]) {

    if (argc > 1) {
        write(STDERR_FILENO, error_message, strlen(error_message));
        return 1;
    }

    vec v1;
    construct_string(&v1);
    char *t = (char *) calloc(100, sizeof(char));
    strcpy(t, "/bin/");
    append_string(&v1, t);
    append_string(&v1, NULL);
    PATH = v1.string;

    do {
        comnd_strct **array = get_commands();
        execute_childs(array);
        free_memory(array);
    } while (true);

    return 0;
}
